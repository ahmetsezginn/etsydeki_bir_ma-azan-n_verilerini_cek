#main
from selenium import webdriver
from openpyxl import Workbook
import os
import re
import title_cek
import hashtag_cek
import description_cek
import resimleri_cek

# Web sayfasını almak için Chrome seçenekleri
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--incognito")

# Hedef Klasör
hedef_klasor = "C:\\Users\\MacTac\\Desktop\\siteden veri çekme\\hastag"

def main():
    # Excel dosyası oluştur
    workbook = Workbook()
    worksheet = workbook.active

    # URL'lerin listesi
    urls = ['https://www.etsy.com/listing/1115340779/world-map-machine-embroidery-design?',

            'https://www.etsy.com/listing/961493520/gnome-with-flowers-machine-embroidery?',

            'https://www.etsy.com/listing/998146235/gnome-couple-machine-embroidery-design?',

            'https://www.etsy.com/listing/1064513331/halloween-witch-machine-embroidery?',

            'https://www.etsy.com/listing/979335655/african-woman-machine-embroidery-design?',

            'https://www.etsy.com/listing/931204635/african-woman-machine-embroidery?']

    driver = webdriver.Chrome(options=chrome_options)
    try:
        for index, url in enumerate(urls, start=1):
            driver.get(url)

            # Dosya temelini al ve A sütununa yaz
            dosya_temeli = re.search(r'/(\d+)/', url).group(1)
            worksheet.cell(row=index, column=1, value=dosya_temeli)

            # Diğer fonksiyonları çağır
            title_cek.title_cek(driver, url, worksheet, index)
            hashtag_cek.hashtaglari_cek(driver, url, worksheet, index)
            description_cek.aciklama_cek(driver, url, worksheet, index)
            resimleri_cek.resimleri_indir_ve_kaydet(driver, url, hedef_klasor)
    except Exception as e:
        print("Bir hata oluştu:", e)
    finally:
        driver.quit()

    # Excel dosyasını kaydet
    workbook.save(os.path.join(hedef_klasor, "hashtag-title.xlsx"))

if __name__ == "__main__":
    main()